# Kodi-plugin.video.blackeagleplaylist
Taking ownership of plugin.video.blackeagleplaylist previously owned by Avigdork
See: https://github.com/dregs1/matrix
